package com.khanAppsNJ.countries.view

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.LiveData
import androidx.recyclerview.widget.RecyclerView
import com.khanAppsNJ.countries.R
import com.khanAppsNJ.countries.model.Country
/**
 * The CountriesAdapter class extends the RecyclerView.Adapter class and is used to bind
 * the data in the list of countries to the RecyclerView.
 */
class CountriesAdapter(private val countries: List<Country>?) : RecyclerView.Adapter<CountriesAdapter.ViewHolder>() {


    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val nameAndRegion = view.findViewById<TextView>(R.id.CnameAndregion_tv)
        private val capital = view.findViewById<TextView>(R.id.Ccapital_tv)
        private val code = view.findViewById<TextView>(R.id.Ccode_tv)

        /**
         * The bind function is used to bind the data for a single country to the RecyclerView item.
         * @param country: The country data to be displayed in the RecyclerView item.
         */
        fun bind(country: Country) {
            nameAndRegion.text = "${country.name}, ${country.region}"
            capital.text = country.capital
            code.text = country.code
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.country_item,parent,false)
        return ViewHolder(view)
    }

    /**
     * The getItemCount method is used to get the number of countries in the list.
     * @return The number of countries in the list.
     */
    override fun getItemCount(): Int {
        return countries!!.size
    }

    /**
     * The onBindViewHolder method is used to bind the data for a single country to the RecyclerView item.
     * @param holder: The ViewHolder for the RecyclerView item.
     * @param position: The position of the country in the list.
     */
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(countries!![position])
    }
}
