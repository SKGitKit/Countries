package com.khanAppsNJ.countries.network

import com.khanAppsNJ.countries.model.Country
import retrofit2.Call
import retrofit2.http.GET
/**
 * Interface for making network requests to retrieve a list of countries
 */
interface ApiService {

    /**
     * Perform a GET request to retrieve a list of countries
     * @return A Call object that can be used to make the network request
     */
    @GET("db25946fd77c5873b0303b858e861ce724e0dcd0/countries.json")
    suspend fun getCountries(): List<Country>

    companion object {
        fun create(): ApiService {
            val retrofit = ApiClient.getClient()
            return retrofit!!.create(ApiService::class.java)
        }
    }

}
